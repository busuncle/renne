"Renne"

I have no time on writing this in detail!

W,S,A,D stand for up,down,left,right respectively.
J is attack, L is run.
U is useless, don't press it!
Esc is the exit button.


enjoy your geek life
----------------------
Copyright 2012 busuncle.
http://code.google.com/p/renne/
